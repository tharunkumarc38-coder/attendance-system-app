require("dotenv").config();

const bcrypt = require("bcryptjs");
const mongoose = require("mongoose");
const User = require("./models/User");

async function seedDatabase() {
  const mongoUri = process.env.MONGO_URI;
  const studentPassword = process.env.SEED_STUDENT_PASSWORD;
  const facultyPassword = process.env.SEED_FACULTY_PASSWORD;

  if (!mongoUri || !studentPassword || !facultyPassword) {
    throw new Error(
      "Set MONGO_URI, SEED_STUDENT_PASSWORD, and SEED_FACULTY_PASSWORD before seeding."
    );
  }

  await mongoose.connect(mongoUri);

  const users = [
    {
      username: "Tharun",
      registerNumber: "Tharun",
      password: await bcrypt.hash(studentPassword, 12),
      role: "STUDENT",
      name: "Tharun Kumar",
      studentId: "2",
      department: "CSE",
      year: "3"
    },
    {
      username: "vimal",
      password: await bcrypt.hash(facultyPassword, 12),
      role: "FACULTY",
      name: "Dr. Vimal",
      department: "CSE"
    }
  ];

  for (const user of users) {
    await User.updateOne(
      { username: user.username },
      { $set: user },
      { upsert: true, runValidators: true }
    );
  }

  console.log("Seed users were created or updated.");
}

seedDatabase()
  .catch((error) => {
    console.error("Database seeding failed:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await mongoose.disconnect();
  });