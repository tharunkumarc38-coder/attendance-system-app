import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAttendance, getAttendanceSummary } from "../api";

function Attendance() {
  const navigate = useNavigate();
  const [summary, setSummary] = useState(null);
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    Promise.all([getAttendanceSummary(), getAttendance()])
      .then(([result, entries]) => {
        if (!active) return;
        setSummary(result);
        setRecords(Array.isArray(entries) ? entries : []);
      })
      .catch((err) => { if (active) setError(err.message || "Unable to load attendance."); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  if (loading) return <section className="attendance-page"><p role="status">Loading attendance...</p></section>;
  if (error) return <section className="attendance-page"><p role="alert">{error}</p></section>;

  return (
    <section className="attendance-page">
      <div className="attendance-header">
        <div><button type="button" onClick={() => navigate("/")}>← Back to Dashboard</button><h1>Attendance</h1><p>Daily attendance records and eligibility summary</p></div>
        <div className="attendance-icon" aria-hidden="true">📊</div>
      </div>
      <div className="attendance-overview">
        <div className="attendance-summary">
          <p>Overall Attendance</p>
          <h2>{summary?.attendancePercentage ?? 0}%</h2>
          <span>{summary?.isEligible ? "Eligible" : "Below minimum"} · Minimum {summary?.minimumRequired ?? 75}%</span>
        </div>
        <div className="attendance-stat"><div><strong>{summary?.attendedClasses ?? 0}</strong><span>Present</span></div></div>
        <div className="attendance-stat"><div><strong>{Math.max((summary?.totalClasses ?? 0) - (summary?.attendedClasses ?? 0), 0)}</strong><span>Absent</span></div></div>
        <div className="attendance-stat"><div><strong>{summary?.totalClasses ?? 0}</strong><span>Total Classes</span></div></div>
      </div>
      <div className="subject-attendance">
        <div className="section-heading"><h2>Attendance Records</h2><p>Records supplied by the attendance service</p></div>
        {records.length === 0 ? <p>No attendance records found.</p> : <div className="attendance-table">
          <div className="table-header"><span>Date</span><span>Student ID</span><span>Status</span></div>
          {records.map((record) => <div className="table-row" key={record._id || `${record.studentId}-${record.date}`}>
            <span>{record.date}</span><span>{record.studentId}</span><strong>{record.status}</strong>
          </div>)}
        </div>}
      </div>
    </section>
  );
}

export default Attendance;
